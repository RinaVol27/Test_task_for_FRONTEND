CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    surname VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    lastname VARCHAR(255) NULL,
    date_of_birth DATE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    post VARCHAR(255) NOT NULL, --Должность
    photo VARCHAR(1000) NOT NULL, 
    link_tg VARCHAR(255) NOT NULL,
    salary_rub integer not null, -- Зарплата в рублях
    date_of_employment DATE NOT NULL, --Дата приёма на работу
    form_work VARCHAR(255) NOT NULL --Форма работы
);

insert into users (surname, name, lastname, date_of_birth, phone, email, post, photo, link_tg, salary_rub, date_of_employment, form_work)
values
('Волчкова', 'Арина', 'Максимовна', '27.06.2005', '+79885674334', '11111@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Гулидов', 'Александр', 'Евгеньевич', '27.06.2005', '+79885674334', '22222@gmail.com', 'Программист', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Летунов', 'Дмитрий', 'Андреевич', '27.06.2005', '+79885674334', '33333@gmail.com', 'Дизайнер', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Мальцев', 'Денис', 'Дмитриевич', '27.06.2005', '+79885674334', '44444@gmail.com', 'Администратор', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Гусева', 'Снежана', 'Евгеньевна', '27.06.2005', '+79885674334', '55555@gmail.com', 'Техник', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Лагутин', 'Никита', 'Павлович', '27.06.2005', '+79885674334', '66666@gmail.com', 'Программист', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Будовская', 'София', 'Александровна', '27.06.2005', '+79885674334', '77777@gmail.com', 'Повар', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Кузьмина', 'Екатерина', 'Артёмовна', '27.06.2005', '+79885674334', '88888@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Фисун', 'Полина', 'Анатольевна', '27.06.2005', '+79885674334', '99999@gmail.com', 'Техник', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Новиков', 'Арсений', 'Алексеевич', '27.06.2005', '+79885674334', '101010@gmail.com', 'Дизайнер', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Ольшанский', 'Святослав', 'Игоревич', '27.06.2005', '+79885674334', '121212@gmail.com', 'Разработчик', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Голяков', 'Трофим', 'Сергеевич', '27.06.2005', '+79885674334', '131313@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Федосеева', 'Злата', 'Алексеевна', '27.06.2005', '+79885674334', '141414@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Египцев', 'Матвей', 'Александрович', '27.06.2005', '+79885674334', '151515@gmail.com', 'Разработчик', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Суркова', 'Софья', 'Павловна', '27.06.2005', '+79885674334', '161616@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Карандеева', 'Дарья', 'Сергеевна', '27.06.2005', '+79885674334', '171717@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Варлашина', 'Анна-Мария', 'Андреевна', '27.06.2005', '+79885674334', '181818@gmail.com', 'Разработчик', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Фридман', 'Елизавета', 'Вениаминовна', '27.06.2005', '+79885674334', '191919@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Неволина', 'Галина', 'Александровна', '27.06.2005', '+79885674334', '202020@gmail.com', 'Разработчик', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Брыль', 'Иван Пётр', '', '27.06.2005', '+79885674334', '212121@gmail.com', 'Программист', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Дронова', 'Анна', 'Андреевна', '27.06.2005', '+79885674334', '232323@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Цвелёв', 'Тихон', 'Алексеевич', '27.06.2005', '+79885674334', '242424@gmail.com', 'Программист', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Лабазников', 'Егор', 'Андреевич', '27.06.2005', '+79885674334', '252525@gmail.com', 'Разработчик', 'https://drive.google.com/file/d/1U14tDbE0rQqi2f_gkvFFeN_PYvb2OT_i/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Кузнецова', 'Елизавета', 'Сергеевна', '27.06.2005', '+79885674334', '262626@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Скугарова', 'Анастасия', 'Дмитриевна', '27.06.2005', '+79885674334', '272727@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно'),
('Бурда', 'Елизавета', 'Сергеевна', '27.06.2005', '+79885674334', '2828228@gmail.com', 'Программист', 'https://drive.google.com/file/d/19QgfAqOECx6MuBOnYYL8rzJt7DRnNSZL/view?usp=drive_link', 'https://t.me/vol_rina', 70000, '01.07.2024', 'удаленно')