//select user_id, surname, name, lastname, photo, post from users
window.onload = function() {
    fetch('http://localhost:3000/users')
        .then(response => response.json())
        .then(data => {
            const table = document.getElementById('data-table-user');
            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `<td id="id">${row.user_id}</td>
                                <td>${row.surname + " " + row.name + " " + row.lastname}</td>
                                <td id="photo"><img src="${row.photo}" alt="Ошибка загрузки фотографии"></td>
                                <td>${row.post}</td>
                                <td><button class="more-button">Подробнее</button></td>`;
                table.querySelector('tbody').appendChild(tr);
            });

            // Добавляем обработчик событий на кнопки "Подробнее"
            document.querySelectorAll('.more-button').forEach(button => {
                button.addEventListener('click', function(event) {
                    const id = event.target.parentElement.parentElement.children[0].textContent;
                    window.localStorage.setItem('user_id', id)
                    window.location.href = './profil.html'; // переход на страницу profil.html
                    // fetch(`http://localhost:3000/use?user_id=${id}`)
                    //     .then(response => response.json())
                    //     .then(data => {
                    //         // Обработка полученных данных
                    //         alert(data);
                    // })
                    //     .catch(error => console.error('Error:', error));
                });
            });
    })
        .catch(error => console.error('Error:', error));
};
