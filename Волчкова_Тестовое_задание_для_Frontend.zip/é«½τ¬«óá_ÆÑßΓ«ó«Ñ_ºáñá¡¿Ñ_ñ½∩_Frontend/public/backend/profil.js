//select user_id, surname, name, lastname, photo, post from users
window.onload = function() {
    let id = window.localStorage.getItem('user_id');
    fetch(`http://localhost:3000/use?user_id=2`)
        .then(response => response.json())
        .then(data => {
            // Обработка полученных данных
    })
        .catch(error => console.error('Error:', error));
};
// field_email.innerHTML = `${users.email}`;