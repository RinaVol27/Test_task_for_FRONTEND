//Перейти на страницу сотрудников
function navigateToPageUsers(){
    window.location.href = "./users_data.html";
}
//Перейти на страницу Профиля
function navigateToPageProfil(){
    window.location.href = "./profil.html";
}
//Перейти на страницу статистики
function navigateToPageStatistics(){
    window.location.href = "./statistics.html";
}
//Перейти